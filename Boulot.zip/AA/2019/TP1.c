#include <stdlib.h>
#include <stdio.h>
#include <time.h>


/**
	Reading and writing data
 */
 
int left (int tab[], int indice){
	return (2*indice+1);
}

int right (int tab[], int indice){
	return (2*indice+2);
}

int parent (int tab[], int indice){
	return ((indice-1)/2);
}

void Permut (int tab[], int a, int b){
	int tempo = tab[a];
	tab[a] = tab[b];
	tab[b] = tempo;
}

void read_data( FILE *datain, int **dataout, int *n, int *k ) {
	int *data;
	
	if(fscanf(datain, "%d", n)==1){}
	else perror("Erreur lecteur");
	if(fscanf(datain, "%d", k)==1){}
	else perror("Erreur lecteur");
	*dataout = (int *)malloc( (*n) * sizeof(int) );
	data=*dataout;
	
	for ( int i=0; i< *n; ++i, ++data )
		if(fscanf( datain, "%d", data )==1){}
		else perror("Erreur lecteur");
}

void print_data(int *tableau, int taille) {
        for( int i=0; i<taille; ++i)
		printf( "%d ", tableau[i] );
	printf("\n");
}

void bulle( int tab[], int n, int k){
	int med;
	for (int i=n-1; i>=n-k; --i){
		for (int j=0; j<n-1; ++j){
			if (tab[j] > tab[j+1]){
				med = tab[j];
				tab[j]=tab[j+1];
				tab[j+1] = med;
			}
		}
	}
	print_data(tab, n);
		
}

void PercolateDown(int tab[], int size, int indice){
	int l = left(tab, indice);
	int r = right(tab, indice);
	int m;
	
	if (l <= size && tab[indice] < tab[l]){
		m = l;
	} else {
		m = indice;
	}
	if (r <= size && tab[m] < tab[r])
		m = r;
	
	if (m != indice){
		Permut(tab, indice, m);
		PercolateDown(tab, size, m);
	}
}

int Remove(int tab[], int size){
	int m = tab[0];
	tab[0] = tab[size];
	size = size--;
	PercolateDown(tab, size, 0);
	return m;
}

void BuildHeap(int tab[], int size){
	for (int i = (size/2-1); i>=0; i--){
		PercolateDown(tab, size, i);
	}
}

void PercolateUp (int tab[], int indice){
	int j = parent(tab, indice);
	printf("%d :j, %d : valeur parent \n ", j, tab[j]);
	while (j >= 0 && tab[j] < tab[indice]){
		print_data(tab, 7);
		Permut(tab, indice, j);
		indice = j;
		j = parent(tab, indice);
	}
}

void Add(int tab[], int size, int e){
	size++;
	tab[size] = e;
	printf("%d : valeur, ", tab[size]);
	PercolateUp(tab, size);
}

int main( int argc, char **argv ) {
	int *data;
	int n, k, max;
	FILE *f_in;
	if ( argc > 1 )
		f_in = fopen(argv[1], "r");
	else
		f_in = stdin;
	read_data(f_in, &data, &n, &k);
	
	
	//print_data(data,n);
	//BuildHeap(data, n-1);
	//PercolateDown(data, n, 2);
	//print_data(data,n);
	/*for (int i = 0; i < k; i++){
		Remove(data, n);
	}
	*/ 
	print_data(data, n);
	
	
	int length = n+5;
	int tab2[length];
	
	for (int i = 0; i < n; i++){
		Add(tab2, i-1, data[i]);
	}
	print_data(tab2, n);
	
	for (int i = 0; i < k; i++){
		Remove(tab2, n);
	}
	print_data(tab2, n);
	
	//bulle( data, n, k);
	//printf("%d, %d, %d", right(data, 3), left(data, 3), parent(data, 3));
	
	return 0;
}


