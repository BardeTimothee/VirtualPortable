#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define MAX_LENGTH 100

typedef struct {
	int size;
	int length;

	int *values;
} heap;

/**
	Reading and writing data
 */
void read_data(FILE *datain, int **dataout, int *n, int *k) {
	int *data;

	fscanf(datain, "%d", n);
	fscanf(datain, "%d", k);
	*dataout = (int *)malloc((*n) * sizeof(int));
	data= *dataout;

	for (int i=0; i<*n; ++i, ++data)
		fscanf(datain, "%d", data);
}

void print_data(int *tableau, int taille) {
  for(int i=0; i<taille; ++i)
		printf("%d ", tableau[i]);
	printf("\n");
}

void swap(int *i, int *j) {
	int temp;
	temp = *i;
	*i = *j;
	*j = temp;
}

void bubble_sort(int *tableau, int* tableau2, int taille, int nbAff) {
	int i, j;

	for(i=0; i<nbAff; i++) {
		for(j=0; j<taille-1-i; j++) {
			tableau2[j]++;
			if(tableau[j] > tableau[j+1]) swap(&tableau[j], &tableau[j+1]);
		}
	}
}

int cmpfunc(const void *a, const void *b) {
	return ( *(int*)a - *(int*)b );
}


int parent(int i) {
	return i/2;
}

int left(int i) {
	return 2*i;
}

int right(int i) {
	return 2*i + 1;
}

void percolateDown(heap *T, int i) {
	int l = left(i);
	int r = right(i);
	int m;

	if((l <= T->size) && (T->values[i] < T->values[l])) m = l;
	else m = i;

	if((r <= T->size) && (T->values[m] < T->values[r])) m = r;

	if(m != i) {
		swap(&T->values[i], &T->values[m]);
		percolateDown(T, m);
	}
}

int removeMax(heap *T) {
	int m = T->values[1];

	T->values[1] = T->values[T->size];
	T->size = T->size - 1;
	percolateDown(T, 1);
	return m;
}

void buildHeap(heap *T) {
	int i;

	T->size = T->length;
	for(i=T->size/2; i>0; i--) percolateDown(T, i);
}

void printHeap(heap *T) {
	printf("\n**** AFFICHAGE HEAP ****\n");
	for(int i=1; i<T->size+1; ++i) printf("%d ", T->values[i]);
	printf("\n");
}

void printParent(heap *T, int i) {
	printf("\n** PARENT OF %d **\n: %d\n", i, T->values[parent(i)]);
}

void printLeft(heap *T, const int i) {
	printf("\n** LEFT OF %d **\n: %d\n", i, T->values[left(i)]);
}

void printRight(heap *T, const int i) {
	printf("\n** RIGHT OF %d **\n: %d\n", i, T->values[right(i)]);
}


int main(int argc, char *argv[])
{
	int *data;
	int i, n, k;
	double duree_ms;
	clock_t duree;
	FILE *f_in;


	if (argc == 1)
		f_in = stdin;
	else if (argc == 2 || argc == 3)
		f_in = fopen(argv[1], "r");
	else {
		fprintf(stderr, "NB Argument : argv[2] = 1 for bubble_sort, 2 for qsort, 3 for heap\n");
		return 1;
	}

	/* lecture des donnees */
	read_data(f_in, &data, &n, &k);

	/* affichage du tableau lu */
	printf("Tableau lu :\n");
	print_data(data, n);

	/* Construction Tas */
	heap T;
	T.length = n+1;
	T.values = data;
	/*************************************************************/
	/* C'est sale */
	for(i=T.length-1; i>0; i--) T.values[i] = T.values[i-1];
	/*************************************************************/

	/* Debut du traitement */
	duree = clock();

	/* Bubble Sort */
	if(atoi(argv[2]) == 1) {
		int tableau2[n];
		for(i=0; i<n; i++)
			tableau2[i] = 0;

		bubble_sort(data, tableau2, n, k);

		/* Affichage tableau traite */
		/*printf("Tableau traite :\n");
		print_data(data, n);*/

		/* output result. */
		printf("Extraction des %d plus grands : ", k);
		for(i=n-1; i>n-k-1; i--) printf("%d ", data[i]);
	  	printf("\n");

	  	printf("HEY\n%d\n", tableau2[9]);
	  	printf("HEY\n%d\n", tableau2[n-11]);
	  	printf("HEY\n%d\n", tableau2[n-2]);

	  	/* Fin du traitement */
		duree = clock() - duree;
		duree_ms = duree / (double)CLOCKS_PER_SEC*1000;
	} 

	/* QSort */
	else if(atoi(argv[2]) == 2) {
		qsort(data, n, sizeof(int), cmpfunc);

		/* Affichage tableau traite */
		/*printf("Tableau traite :\n");
		print_data(data, n);*/

		/* output result. */
		printf("Extraction des %d plus grands : ", k);
		for(i=n-1; i>n-k-1; i--) printf("%d ", data[i]);
	  	printf("\n");

	  	/* Fin du traitement */
		duree = clock() - duree;
		duree_ms = duree / (double)CLOCKS_PER_SEC*1000;
	}

	/* Heap */
	else if(atoi(argv[2]) == 3) {
		buildHeap(&T);

		/* Affichage tableau traite */
		/*printf("Tableau traite :\n");
		for(i=1; i<T.length; i++) printf("%d ", T.values[i]);
		printf("\n");*/

		/* output result. */
		printf("Extraction des %d plus grands : ", k);
		for(i=0; i<k; i++) printf("%d ", removeMax(&T));
	  	printf("\n");

	  	/* Fin du traitement */
		duree = clock() - duree;
		duree_ms = duree / (double)CLOCKS_PER_SEC*1000;

		/*printHeap(&T);
		printParent(&T, 2);
		printLeft(&T, 1);
		printRight(&T, 1);*/
	}

	printf("fait en %7.fms\n", duree_ms);

	free(data);
	return 0;
}
