#pragma once

#include <stdio.h>
#include <stdlib.h>

struct Node {
	int* value;
	struct Node *next;
};

typedef struct {
	int size;
	int vectorSize;
	struct Node *first;
} Queue;

Queue *initQueue(const int vectorSize);

void push(Queue *queue, const int* value);

int* pop(Queue *queue);

int contains(const Queue *queue, const int* value);
