#include "files.h"

Matrix readFileToMatrix(const char *file_path) {
	Matrix mat;
	FILE *file;

	file = fopen(file_path, "r");
	if(file == NULL) {
		fprintf(stderr, "Error : unable to open \"%s\"\n", file_path);
		exit(EXIT_FAILURE);
	}

	fscanf(file, "%d %d ", &mat.size, &mat.p);
	mat.values = malloc(sizeof(int*) * mat.size);
	for(int i=0; i<mat.size; ++i) {
		mat.values[i] = malloc(sizeof(int) * mat.size);
		for (int j=0; j<mat.size; ++j)
			fscanf(file, "%d ", &mat.values[i][j]);
	}

	fclose(file);
	return mat;
}
