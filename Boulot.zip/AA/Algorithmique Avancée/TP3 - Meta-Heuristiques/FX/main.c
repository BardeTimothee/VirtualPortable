#include "matrix.h"
#include "files.h"
#include "meta_h.h"

#define NB_ESSAIS 6
#define NB_CHOISIS 20
#define NB_DEPL_MAX 100
#define MAX_LIST_SIZE 50

int main(int argc, char *argv[])
{
	printf("\n-----------------\n\n");
	if(argc != 2) {
		fprintf(stderr, "Usage : ./%s <file>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	srand(time(NULL));

	// int *X;
	int X0[6] = {1, 1, 1, 1, 0, 1};
	Matrix Q;

	Q = readFileToMatrix(argv[1]);
	printMatrix(Q);

	 //printf("\n1 : %d\n", resolveF(Q, X0));
    /*
	 printf("\n2 : ");
	 int *X1 = meilleur_voisin(Q, X0);
	 for(int i=0; i<Q.size; ++i)
	  	printf("%d ", X1[i]);
	 printf("\n%d\n", resolveF(Q, X1));
    */ 
     /////////////////////////////////////////////////////////// 
     /*
	printf("\n3 : ");
	steepest_hill_climbing(Q, X0, NB_CHOISIS, NB_ESSAIS);
	printf("Meilleur sol : \n");
	for(int i=0; i<Q.size; ++i)
	 	printf("%d ", X0[i]);
	printf("\n%d\n", resolveF(Q, X0)); */ ///////
	// printf("\n4 :\n");
	// int *X4 = tabou(Q, MAX_LIST_SIZE, NB_DEPL_MAX);
	// for(int i=0; i<Q.size; ++i)
	// 	printf("%d ", X4[i]);
	// printf("\n%d\n", resolveF(Q, X4));


	// printf("\n*** STEEPEST HILL CLIMBING ***\n");
	//X = initialSolution(Q);
	// steepest_hill_climbing(Q, X, NB_CHOISIS, NB_ESSAIS);
	// printf("NB_ESSAIS : %d\nNB_CHOISIS : %d\nBest solution : ", NB_ESSAIS, NB_CHOISIS);
	// for(int i=0; i<Q.size; ++i)
	// 	printf("%d ", X[i]);
	// printf("\n");
    //
	// printf("Best value : %d\n", resolveF(Q, X));


	 printf("\n*** TABOU ***\n");
	 printf("MAX_LIST_SIZE : %d\nNB_DEPL_MAX : %d\nBest solution : ", MAX_LIST_SIZE, NB_DEPL_MAX);
	 int *X = tabou(Q, MAX_LIST_SIZE, NB_DEPL_MAX);
	 for(int i=0; i<Q.size; ++i)
	 	printf("%d ", X[i]);
	 printf("\n");
    
	 printf("Best value : %d\n", resolveF(Q, X));

	printf("\n-----------------\n\n");
	return 0;
}
