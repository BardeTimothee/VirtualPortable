#include "matrix.h"

void printMatrix(const Matrix mat) {
	printf("Matrix Q size : %d\nMatrix Q number : %d\n", mat.size, mat.p);
	for(int i=0; i<mat.size; ++i) {
		for(int j=0; j<mat.size; ++j)
			printf("%3d ", mat.values[i][j]);
		printf("\n");
	}
}

/*Matrix* transpose(const Matrix mat) {
	return NULL;
}*/
