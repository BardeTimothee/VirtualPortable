#pragma once

#include <stdio.h>
#include <stdlib.h>

typedef struct {
	int size;
	int p;
	int **values;
} Matrix;

void printMatrix(const Matrix mat);
