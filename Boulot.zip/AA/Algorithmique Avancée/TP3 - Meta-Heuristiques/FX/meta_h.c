#include "meta_h.h"

int* initialSolution(const Matrix mat) {
	int *vector = malloc(sizeof(int*) * mat.size);
	int sum = 0;

	while(sum < mat.p) {
		sum = 0;
		for(int i=0; i<mat.size; ++i) {
			vector[i] = rand()%2;
			sum += vector[i];
		}
	}
	return vector;
}

int resolveF(const Matrix Q, const int* X) {
	int *buffer = malloc(sizeof(int) * Q.size);
	int v;
	int ret;

	for(int i=0; i<Q.size; ++i) {
		v = 0;
		for(int j=0; j<Q.size; ++j)
			v += Q.values[i][j] * X[j];
		buffer[i] = v;
	}

	ret = 0;
	for(int i=0; i<Q.size; ++i)
		ret += buffer[i] * X[i];

	return ret;
}

int* meilleur_voisin(const Matrix Q, const int* X) {
	int* newX = malloc(sizeof(int) * Q.size);
	int* X_tmp = malloc(sizeof(int) * Q.size);
	int meilleur;
	int meilleur_tmp;
	int sum=0;
	int k=0;

	// while(sum < Q.p) {
	// 	sum = 0;
		for(int i=0; i<Q.size; ++i)
			X_tmp[i] = X[i];
		X_tmp[k] = (X[k]+1) %2;
		for(int i=0; i<Q.size; ++i)
			sum += X_tmp[i];
		++k;
	// }

	meilleur = resolveF(Q, X_tmp);
	for(int i=0; i<Q.size; ++i)
		newX[i] = X_tmp[i];

	for(int i=1; i<Q.size; ++i) {
		// sum = 0;
		X_tmp[i-1] = (X_tmp[i-1]+1)%2;
		X_tmp[i] = (X_tmp[i]+1) %2;

		// for(int j=0; j<Q.size; ++j)
		// 	sum += X_tmp[j];

		// if(sum >= Q.p) {
			meilleur_tmp = resolveF(Q, X_tmp);
			if(meilleur_tmp < meilleur) {
				meilleur = meilleur_tmp;
				for(int j=0; j<Q.size; ++j)
				newX[j] = X_tmp[j];
			}
		// }

	}

	return newX;
}

void steepest_hill_climbing(const Matrix Q, int* X, const int MAX_choix, const int MAX_essais) {
	int STOP;
	int nb_essais;
	int nb_choisis;
	int meilleur;
	int *meilleur_voisin_vec = malloc(sizeof(int) * Q.size);
	int meilleur_voisin_value;
	int *X_tmp = malloc(sizeof(int) * Q.size);

	STOP = 0;
	nb_essais = 0;
	nb_choisis = 0;
	meilleur = resolveF(Q, X);
	meilleur_voisin_vec = meilleur_voisin(Q, X);
	meilleur_voisin_value = resolveF(Q, meilleur_voisin_vec);
	do {
		++nb_essais;
		do {
			++nb_choisis;
			if(meilleur_voisin_value < meilleur) {
				meilleur = meilleur_voisin_value;
				for(int i=0; i<Q.size; ++i)
					X[i] = meilleur_voisin_vec[i];
				printf("nb_essais, nb_choisis : %d, %d\n",nb_essais, nb_choisis);
				printf("val = %d\n", resolveF(Q, X));
			}
			else
				STOP = 1;
			meilleur_voisin_vec = meilleur_voisin(Q, meilleur_voisin_vec);
			meilleur_voisin_value = resolveF(Q, meilleur_voisin_vec);
		} while(nb_choisis != MAX_choix && !STOP);
		STOP = 0;
		nb_choisis = 0;
		int X_tmp[6] = {0, 0, 1, 1, 1, 0};
		//X_tmp = initialSolution(Q);
		// meilleur = resolveF(Q, X_tmp);
		for(int i=0; i<Q.size; ++i)
			printf("%d ", X_tmp[i]);
		meilleur_voisin_vec = meilleur_voisin(Q, X_tmp);
		meilleur_voisin_value = resolveF(Q, meilleur_voisin_vec);
		if(nb_essais <= MAX_essais) {
			// printf("***nb_essais : %d\n", nb_essais);
			// for(int i=0; i<Q.size; ++i)
			// printf("%d ", X_tmp[i]);
			// printf("\n");

		}
	} while(nb_essais <= MAX_essais);
}

int** voisins_non_tabou(const Matrix Q, const int* X, const Queue* tabou) {
	int nb_voisins_non_tabou = 0;
	int **mat_voisins_non_tabou = malloc(sizeof(int *) * Q.size);
	int *X_tmp = malloc(sizeof(int) * Q.size);
	int sum = 0;

	for(int i=0; i<Q.size; ++i)
		X_tmp[i] = X[i];

	X_tmp[0] = (X_tmp[0]+1)%2;
	for(int i=0; i<Q.size; ++i)
		sum += X_tmp[i];
	if(sum >= Q.p && !contains(tabou, X_tmp)) {
		mat_voisins_non_tabou[nb_voisins_non_tabou] = malloc(sizeof(int) * Q.size);
		for(int i=0; i<Q.size; ++i)
			mat_voisins_non_tabou[nb_voisins_non_tabou][i] = X_tmp[i];
		++nb_voisins_non_tabou;
	}

	for(int i=1; i<Q.size; ++i) {
		X_tmp[i-1] = (X_tmp[i-1]+1)%2;
		X_tmp[i] = (X_tmp[i]+1)%2;
		sum = 0;
		for(int j=0; j<Q.size; ++j)
			sum += X_tmp[j];
		if(sum >= Q.p && !contains(tabou, X_tmp)) {
			mat_voisins_non_tabou[nb_voisins_non_tabou] = malloc(sizeof(int) * Q.size);
			for(int j=0; j<Q.size; ++j)
				mat_voisins_non_tabou[nb_voisins_non_tabou][j] = X_tmp[j];
			++nb_voisins_non_tabou;
		}
	}

	if(nb_voisins_non_tabou == 0)
		return NULL;

	for(int i=nb_voisins_non_tabou; i<Q.size; ++i) {
		mat_voisins_non_tabou[i] = NULL;
	}
	return mat_voisins_non_tabou;
}

int* meilleur_voisin_non_tabou(Matrix Q, int **voisins) {
	if(voisins[0] == NULL) {
		return NULL;
	}

	int *best_vec = malloc(sizeof(int) * Q.size);
	int best_val;
	int candidat;

	for(int i=0; i<Q.size; ++i)
		best_vec[i] = voisins[0][i];
	best_val = resolveF(Q, best_vec);

	for(int i=1; i<Q.size; ++i) {
		if(voisins[i] == NULL)
			return best_vec;
		candidat = resolveF(Q, voisins[i]);
		if (candidat < best_val) {
			for(int j=0; j<Q.size; ++j)
				best_vec[j] = voisins[i][j];
			best_val = candidat;
		}
	}

	return best_vec;
}

int* tabou(const Matrix Q, const int max_list_size, const int nb_depl_max) {
	// int *X = initialSolution(Q);
	int *X = malloc(6 * sizeof(int));
	X[0] = 1;
	X[1] = 0;
	X[2] = 0;
	X[3] = 1;
	X[4] = 1;
	X[5] = 0;

	Queue *tabou = initQueue(Q.size);
	int* msol = malloc(sizeof(int) * Q.size);
	int** voisins;

	push(tabou, X);
	int nb_depl = 0;
	int STOP = 0;
	for (int i=0; i<Q.size; ++i)
		msol[i] = X[i];

	do {
		voisins = voisins_non_tabou(Q, X, tabou);
		if(voisins != NULL)
			X = meilleur_voisin_non_tabou(Q, voisins);
		else
			STOP = 1;
		if(tabou->size == max_list_size)
			pop(tabou);
		push(tabou, X);
		if(resolveF(Q, X) < resolveF(Q, msol)) {
			for(int i=0; i<Q.size; ++i)
				msol[i] = X[i];
		}
		++nb_depl;
		printf("nb_depl : %d\n", nb_depl);
	} while(!STOP && nb_depl < nb_depl_max);
	int * p = pop(tabou);
	for(int i=0; i<Q.size; ++i)
		printf("%d ", p[i]);
	printf("\n");
	return msol;
}
