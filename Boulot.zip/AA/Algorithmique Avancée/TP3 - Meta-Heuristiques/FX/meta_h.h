#pragma once

#include "matrix.h"
#include "time.h"
#include "fifo.h"

int* initialSolution(const Matrix mat);

int resolveF(const Matrix Q, const int* X);

int* meilleur_voisin(const Matrix Q, const int* X);

void steepest_hill_climbing(const Matrix Q, int* X, const int MAX_choix, const int MAX_essais);

int** voisins_non_tabou(const Matrix Q, const int* X, const Queue* tabou);

int* meilleur_voisin_non_tabou(Matrix Q, int **voisins);

int* tabou(const Matrix Q, const int max_list_size, const int nb_depl_max);
