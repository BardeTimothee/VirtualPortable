 
#include "fifo.h"

Queue* initQueue(const int vectorSize)
{
    Queue *queue = malloc(sizeof(*queue));
	queue->size = 0;
	queue->vectorSize = vectorSize;
    queue->first = NULL;

    return queue;
}

void push(Queue *queue, const int* value) {
	struct Node *newNode = malloc(sizeof(*newNode));
	if(queue == NULL || newNode == NULL) {
		fprintf(stderr, "Error : can't create queue or node\n");
		exit(EXIT_FAILURE);
	}

	newNode->value = malloc(sizeof(int) * queue->vectorSize);
	for(int i=0; i<queue->vectorSize; ++i)
		newNode->value[i] = value[i];
	newNode->next = NULL;

	if(queue->first  != NULL) {
		struct Node *actual = queue->first;
		while(actual->next != NULL)
			actual = actual->next;
		actual -> next = newNode;
	}
	else
		queue->first = newNode;

	++queue->size;
}

int* pop(Queue *queue) {
	if(queue == NULL || queue->first == NULL) {
		fprintf(stderr, "Error : trying to pop an empty queue\n");
		exit(EXIT_FAILURE);
	}

	int *value;
	struct Node *toPop = queue->first;
	value = toPop->value;
	queue->first = toPop->next;
	free(toPop);
	--queue->size;

	return value;
}

int contains(const Queue *queue, const int* value) {
	if(queue->first == NULL) {
		fprintf(stderr, "Error : trying to seek into an empty queue\n");
		exit(EXIT_FAILURE);
	}

	struct Node *actual = queue->first;
	int bool;

	while(actual != NULL) {
		bool = 1;
		for(int i=0; i<queue->vectorSize; ++i) {
			if(actual->value[i] != value[i]) {
				bool = 0;
			}
		}
		if(bool)
			return 1;
		if(actual->next == NULL)
			return 0;
		actual = actual->next;
	}
	return 0;
}
