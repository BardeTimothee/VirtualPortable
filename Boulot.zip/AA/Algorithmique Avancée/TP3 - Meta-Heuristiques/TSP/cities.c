#include "cities.h"
#include "tsp.h"

void printCities(const Cities cs) {
	printf("Number of cities : %d\n", cs.n);
	for(int i=0; i<cs.n; ++i)
		printf("%3d %3d %3d\n", cs.values[i].id, cs.values[i].x, cs.values[i].y);
}

double distance(const struct City c1, const struct City c2) {
	return sqrt(pow(c1.x - c2.x, 2) + pow(c1.y - c2.y, 2));
}

void permut(Cities cs, const int i1, const int i2) {
	struct City tmp;
	tmp = cs.values[i1];
	cs.values[i1] = cs.values[i2];
	cs.values[i2] = tmp;
}
