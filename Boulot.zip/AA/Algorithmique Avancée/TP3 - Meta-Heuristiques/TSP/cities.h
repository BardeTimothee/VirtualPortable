#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct {
	int n;
	struct City *values;
} Cities;

struct City {
	int id;
	int x;
	int y;
};

void printCities(const Cities);

double distance(const struct City c1, const struct City c2);

void permut(Cities cs, const int i1, const int i2);
