#include "fifo.h"

Queue* initQueue(const int nb_cities) {
	Queue* queue = malloc(sizeof(*queue));
	queue->size = 0;
	queue->nb_cities = nb_cities;
	queue->first = NULL;
	return queue;
}

void push(Queue* queue, const Cities value) {
	struct Node* newNode = malloc(sizeof(*newNode));
	if(queue == NULL || newNode == NULL) {
		fprintf(stderr, "Error : can't create queue or node\n");
		exit(EXIT_FAILURE);
	}

	newNode->value.values = malloc(sizeof(struct City) * queue->nb_cities);
	newNode->value.n = queue->nb_cities;
	for(int i=0; i<queue->nb_cities; ++i) {
		newNode->value.values[i].id = value.values[i].id;
		newNode->value.values[i].x = value.values[i].x;
		newNode->value.values[i].y = value.values[i].y;
	}
	newNode->next = NULL;

	if(queue->first != NULL) {
		struct Node *actual = queue->first;
		while(actual->next != NULL)
			actual = actual->next;
		actual->next = newNode;
	}
	else
		queue->first = newNode;

	++queue->size;
}

Cities pop(Queue* queue) {
	if(queue == NULL || queue->first == NULL) {
		fprintf(stderr, "Error : trying to pop an empty queue\n");
		exit(EXIT_FAILURE);
	}

	Cities value;
	struct Node *toPop = queue->first;
	value = toPop->value;
	queue->first = toPop->next;
	free(toPop);
	--queue->size;

	return value;
}

int contains(const Queue* queue, const Cities value) {
	if(queue->first == NULL) {
		fprintf(stderr, "Error : trying to seek into an empty queue\n");
		exit(EXIT_FAILURE);
	}

	struct Node* actual = queue->first;
	int bool;

	while(actual != NULL) {
		bool = 1;
		for(int i=0; i<queue->nb_cities; ++i) {
			if(actual->value.values[i].id != value.values[i].id
			|| actual->value.values[i].x != value.values[i].x
			|| actual->value.values[i].y != value.values[i].y) {
				bool = 0;
			}
		}
		if(bool)
			return 1;
		if(actual->next == NULL)
			return 0;
		actual = actual->next;
	}
	return 0;
}
