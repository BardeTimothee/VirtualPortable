#pragma once

#include <stdio.h>
#include <stdlib.h>

#include "cities.h"

struct Node {
	Cities value;
	struct Node* next;
};

typedef struct {
	int size;
	int nb_cities;
	struct Node* first;
} Queue;

Queue* initQueue(const int nb_cities);

void push(Queue* queue, const Cities value);

Cities pop(Queue* queue);

int contains(const Queue* queue, const Cities value);
