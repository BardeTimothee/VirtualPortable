#include "files.h"

Cities readFileToCities(const char* file_path) {
	FILE *file;
	Cities cs;

	file = fopen(file_path, "r");
	if(file == NULL) {
		fprintf(stderr, "Error : unable to open \"%s\"\n", file_path);
		exit(EXIT_FAILURE);
	}

	fscanf(file, "%d", &cs.n);
	cs.values = malloc(sizeof(struct City) * cs.n);
	for(int i=0; i<cs.n; ++i)
		fscanf(file, "%d %d %d", &cs.values[i].id, &cs.values[i].x, &cs.values[i].y);

	fclose(file);
	return cs;
}
