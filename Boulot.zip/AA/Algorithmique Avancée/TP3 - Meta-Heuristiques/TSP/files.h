#pragma once

#include <stdio.h>
#include <stdlib.h>

#include "cities.h"

Cities readFileToCities(const char* file_path);
