#include "files.h"
#include "tsp.h"
#include "fifo.h"

#define NB_DEPL_MAX 10000
#define NB_ESSAIS 50
#define MAX_LIST_SIZE 1000

int main(int argc, char *argv[]) {
	printf("\n----------------\n\n");
	if(argc != 2) {
		fprintf(stderr, "Usage : ./%s <file>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	srand(time(NULL));
	Cities tmp;
	Cities cs;
	Cities co = initialSolution(cs);

	tmp = readFileToCities(argv[1]);
	//cs = meilleur_voisin(tmp);
	//printCities(cs);
	printCities(co);
	printf("res :%lf\n", resolve(cs));
	// printf("1 : %lf\n", resolve(cs));
	// cs = tabou(cs, MAX_LIST_SIZE, NB_DEPL_MAX);
	// printCities(cs);
	// printf("%lf\n", resolve(cs));

	 //printf("\n2 :\n");
	 //Cities bestV = meilleur_voisin(cs);
	 //printCities(bestV);
	 //printf("%lf\n", resolve(bestV));
    //
	// printf("\n3 :\n");
	// cs = steepest_hill_climbing(cs, NB_DEPL_MAX, NB_ESSAIS);
	// printCities(cs);
	// printf("%lf\n", resolve(cs));

	// printf("\n4 :\n");
	// double sum = 0;
	// for(int i=0; i<100; ++i) {
	// 	cs = initialSolution(cs);
	// 	sum += resolve(cs);
	// }
	// sum = sum /100;
	// printf("%lf", sum);


	// printf("\n*** STEEPEST HILL CLIMBING ***\n");
	// cs = readFileToCities(argv[1]);
	// cs = steepest_hill_climbing(cs, NB_DEPL_MAX, NB_ESSAIS);
	// printf("NB_DEPL_MAX : %d\nNB_ESSAIS : %d\nBest solution :\n", NB_DEPL_MAX, NB_ESSAIS);
	// printCities(cs);
	// printf("Best value : %lf\n", resolve(cs));

	// printf("\n*** TABOU ***\n");
	// cs = readFileToCities(argv[1]);
	// printf("MAX_LIST_SIZE : %d\nNB_DEPL_MAX : %d\nBest solution :\n", MAX_LIST_SIZE, NB_DEPL_MAX);
	// cs = tabou(cs, MAX_LIST_SIZE, NB_DEPL_MAX);
	// printCities(cs);
	// printf("Best value : %lf\n", resolve(cs));


	printf("\n----------------\n\n");
	return 0;
}
