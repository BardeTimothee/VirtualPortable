#include "tsp.h"
#include "files.h"
#include "cities.h"

Cities initialSolution(const Cities co) {
	Cities cs;
	cs.n = 7;
	cs.values = malloc(sizeof(struct City) * cs.n);
	cs.values[0].id = 4;
	cs.values[0].x = 12;
	cs.values[0].y = 54;
	cs.values[1].id = 7;
	cs.values[1].x = 93;
	cs.values[1].y = 201;
	cs.values[2].id = 6;
	cs.values[2].x = 168;
	cs.values[2].y = 111;
	cs.values[3].id = 3;
	cs.values[3].x = 165;
	cs.values[3].y = 162;
	cs.values[4].id = 2;
	cs.values[4].x = 78;
	cs.values[4].y = 105;
	cs.values[5].id = 1;
	cs.values[5].x = 171;
	cs.values[5].y = 144;
	cs.values[6].id = 5;
	cs.values[6].x = 78;
	cs.values[6].y = 105;
	/*
	int i, nb_used = 0;
	int used[cs.n];
	Cities solution;

	solution.n = cs.n;
	solution.values = malloc(sizeof(struct City) * cs.n);
	for(int i=0; i<cs.n; ++i)
		used[i] = 0;

	while(nb_used != cs.n) {
		i = rand()%cs.n;
		if(!used[i]) {
			solution.values[nb_used] = cs.values[i];
			used[i] = 1;
			++nb_used;
		}
	}
*/
	return cs;
}

double resolve(const Cities sol) {
	struct City origin;
	origin.x = 0;
	origin.y = 0;
	double res = distance(origin, sol.values[0]);
	printf("dist: %lf \n", res);

	for(int i=1; i<sol.n; ++i) {
		res += distance(sol.values[i-1], sol.values[i]);
		printf("dist: %lf \n", res);
	}
	return (res + distance(sol.values[sol.n-1], origin));
}

Cities meilleur_voisin(const Cities sol) {
	double meilleur_value, candidat_value;
	Cities meilleur, candidat;
	meilleur.n = sol.n;
	candidat.n = sol.n;
	meilleur.values = malloc(sizeof(struct City) * sol.n);
	candidat.values = malloc(sizeof(struct City) * sol.n);

	for(int i=0; i<sol.n; ++i) {
		candidat.values[i].id = sol.values[i].id;
		candidat.values[i].x = sol.values[i].x;
		candidat.values[i].y = sol.values[i].y;
	}

	permut(candidat, 0, 1);
	meilleur_value = resolve(candidat);
	for(int i=0; i<sol.n; ++i) {
		meilleur.values[i].id = candidat.values[i].id;
		meilleur.values[i].x = candidat.values[i].x;
		meilleur.values[i].y = candidat.values[i].y;
	}
	permut(candidat, 0, 1);


	for(int i=0; i<sol.n; ++i) {
		for(int j=0; j<sol.n; ++j) {
			if(i!=j) {
				permut(candidat, i, j);

				candidat_value = resolve(candidat);
				if(candidat_value < meilleur_value) {
					meilleur_value = candidat_value;
					for(int k=0; k<sol.n; ++k) {
						meilleur.values[k].id = candidat.values[k].id;
						meilleur.values[k].x = candidat.values[k].x;
						meilleur.values[k].y = candidat.values[k].y;
					}
				}

				permut(candidat, i, j);
			}
		}
	}

	return meilleur;
}

Cities steepest_hill_climbing(Cities cs, const int MAX_depl, const int MAX_essais) {
	double candidat_value, meilleur_value;
	Cities candidat, meilleur;
	meilleur.n = cs.n;
	candidat.n = cs.n;
	meilleur.values = malloc(sizeof(struct City) * cs.n);
	candidat.values = malloc(sizeof(struct City) * cs.n);

	int nb_depl;
	int STOP;
	int nb_essais = 0;

	int nb_gener = 0;
	meilleur_value = 9999999999;
	double sum = 0;

	do {
		++nb_essais;
		if(nb_gener == 100)
			break;

		STOP = 0;
		nb_depl = 0;
		candidat = initialSolution(cs);
		candidat_value = resolve(candidat);
		sum += candidat_value;

		if(candidat_value < meilleur_value) {
			meilleur_value = candidat_value;
			for(int i=0; i<cs.n; ++i) {
				meilleur.values[i].id = candidat.values[i].id;
				meilleur.values[i].x = candidat.values[i].x;
				meilleur.values[i].y = candidat.values[i].y;
			}
		}

		++nb_gener;
		if(nb_gener == 100)
			break;

		do {
			candidat = meilleur_voisin(meilleur);
			candidat_value = resolve(candidat);
			sum += candidat_value;

			if(candidat_value < meilleur_value) {
				meilleur_value = candidat_value;
				for(int i=0; i<cs.n; ++i) {
					meilleur.values[i].id = candidat.values[i].id;
					meilleur.values[i].x = candidat.values[i].x;
					meilleur.values[i].y = candidat.values[i].y;
				}
			}
			else
				STOP = 1;
			++nb_depl;
			++nb_gener;
			if(nb_gener == 100)
				break;

		} while(nb_depl != MAX_depl && !STOP);
	} while(nb_essais != MAX_essais);

	printf("nb_gener : %d\n", nb_gener);
	printf("sum/100 : %lf", sum/100);
	return meilleur;
}

Cities* voisins_non_tabou(const Cities cs, const Queue* tabou) {
	int nb_voisins_non_tabou = 0;
	Cities cs_tmp;
	cs_tmp.values = malloc(sizeof(struct City) * cs.n);
	Cities *cs_voisins_non_tabou;

	int size=1;
	for(int i=cs.n; i>0; --i)
		size += i;

	cs_voisins_non_tabou = malloc(sizeof(Cities) * size);
	for(int i=0; i<size; ++i)
		cs_voisins_non_tabou[i].values = malloc(sizeof(struct City) * cs.n);

	cs_tmp.n = cs.n;
	for(int i=0; i<cs.n; ++i) {
		cs_tmp.values[i].id = cs.values[i].id;
		cs_tmp.values[i].x = cs.values[i].x;
		cs_tmp.values[i].y = cs.values[i].y;
	}

	permut(cs_tmp, 0, 1);
	if(!contains(tabou, cs_tmp)) {
		cs_voisins_non_tabou[nb_voisins_non_tabou].n = cs.n;
		for(int i=0; i<cs.n; ++i) {
			cs_voisins_non_tabou[nb_voisins_non_tabou].values[i].id = cs_tmp.values[i].id;
			cs_voisins_non_tabou[nb_voisins_non_tabou].values[i].x = cs_tmp.values[i].x;
			cs_voisins_non_tabou[nb_voisins_non_tabou].values[i].y = cs_tmp.values[i].y;
		}
		++nb_voisins_non_tabou;
	}
	permut(cs_tmp, 0, 1);

	for(int i=0; i<cs.n; ++i) {
		for(int j=i; j<cs.n; ++j) {
			permut(cs_tmp, i, j);
			if(!contains(tabou, cs_tmp)) {
				cs_voisins_non_tabou[nb_voisins_non_tabou].n = cs.n;
				for(int k=0; k<cs.n; ++k) {
					cs_voisins_non_tabou[nb_voisins_non_tabou].values[k].id = cs_tmp.values[k].id;
					cs_voisins_non_tabou[nb_voisins_non_tabou].values[k].x = cs_tmp.values[k].x;
					cs_voisins_non_tabou[nb_voisins_non_tabou].values[k].y = cs_tmp.values[k].y;
				}
				++nb_voisins_non_tabou;
			}
			permut(cs_tmp, i, j);
		}
	}

	if(nb_voisins_non_tabou == 0)
		return NULL;

	for(int i=nb_voisins_non_tabou; i<size; ++i)
		cs_voisins_non_tabou[i].values = NULL;

	return cs_voisins_non_tabou;
}

Cities meilleur_voisin_non_tabou(Cities* cs_vec) {
	Cities best_cs;

	if(cs_vec == NULL) {
		best_cs.values = NULL;
		return best_cs;
	}

	best_cs.values = malloc(sizeof(struct City) * cs_vec[0].n);
	double best_val, candidat;

	best_cs.n = cs_vec[0].n;
	for(int i=0; i<cs_vec[0].n; ++i) {
		best_cs.values[i].id = cs_vec[0].values[i].id;
		best_cs.values[i].x = cs_vec[0].values[i].x;
		best_cs.values[i].y = cs_vec[0].values[i].y;
	}
	best_val = resolve(best_cs);

	for(int i=1; i<cs_vec[0].n; ++i) {
		if(cs_vec[i].values == NULL)
			return best_cs;
		candidat = resolve(cs_vec[i]);
		if(candidat < best_val) {
			for(int j=0; j<cs_vec[0].n; ++j) {
				best_cs.values[j].id = cs_vec[i].values[j].id;
				best_cs.values[j].x = cs_vec[i].values[j].x;
				best_cs.values[j].y = cs_vec[i].values[j].y;
			}
			best_val = candidat;
		}
	}

	return best_cs;
}

Cities tabou(const Cities csA, const int max_list_size, const int nb_depl_max) {
	Cities cs = /*csA*/initialSolution(csA);
	// Cities cs = readFileToCities("tsp_s1_v2.txt");
	Queue *tabou = initQueue(csA.n);
	Cities msol;
	msol.values = malloc(sizeof(struct City) * csA.n);
	Cities *voisins;

	double sum = resolve(cs);

	push(tabou, cs);
	int nb_depl = 0;
	int STOP = 0;

	int nb_gener = 1;

	msol.n = csA.n;
	for(int i=0; i<csA.n; ++i) {
		msol.values[i].id = cs.values[i].id;
		msol.values[i].x = cs.values[i].x;
		msol.values[i].y = cs.values[i].y;
	}

	do {
		// if(nb_gener >= 100)
		// 	break;
		voisins = voisins_non_tabou(cs, tabou);
		if(voisins != NULL)
			cs = meilleur_voisin_non_tabou(voisins);
		else
			STOP = 1;
		if(tabou->size >= max_list_size)
			pop(tabou);
		push(tabou, cs);
		++nb_gener;
		sum += resolve(cs);
		if(resolve(cs) < resolve(msol)) {
			for(int i=0; i<cs.n; ++i) {
				msol.values[i].id = cs.values[i].id;
				msol.values[i].x = cs.values[i].x;
				msol.values[i].y = cs.values[i].y;
			}
		}
		++nb_depl;
		// printf("%d %d\n", tabou->size, nb_depl);
	} while(!STOP && nb_depl < nb_depl_max);

	// Cities last = pop(tabou);
	// printCities(last);
	printf("nb_gener : %d\n", nb_gener);
	printf("sum/100 : %lf\n", sum/100);
	return msol;
}

Cities meilleur_voisin_2_opt(const Cities cs) {
	Cities ret;
	ret.n = cs.n;
	ret.values = malloc(sizeof(struct City) * cs.n);

	// for(int i=0; i<cs.n; ++i) {
	// 	ret.values[i].id = cs.values[i].id;
	// 	ret.values[i].x = cs.values[i].x;
	// 	ret.values[i].y = cs.values[i].y;
	// }

	for(int i=0; i<cs.n-1; ++i) {
		for(int j=0; j<cs.n-1; ++j) {
			if(i != 0) {
				if(j != i-1 && j != i && j != i+1) {
					if(
						((distance(cs.values[i], cs.values[i+1])) + (distance(cs.values[j], cs.values[j+1])))
						>
						((distance(cs.values[i], cs.values[j])) + (distance(cs.values[i+1], cs.values[j+1])))
					) {
						ret.values[j] = cs.values[i+1];
						ret.values[i+1] = cs.values[j];
						if(i == j) {
							for(int k=0; k<cs.n; ++k) {
								if(k!=j && k != i+1) {
									ret.values[k] = cs.values[k];
								}
							}
						}
						else if(i<j){
							int done = 0;
							for(int k=0; k<cs.n; ++k) {
								if(!(k > i && k < j)) {
									ret.values[k] = cs.values[k];
								}
								else if(!done) {
									int cpt=0;
									for(int l=j; l>(j-i)/2; --l) {
										ret.values[cpt] = cs.values[l];
										cpt++;
									}
									done = 1;
								}
							}
						}
						else {
							int done = 0;
							for(int k=0; k<cs.n; ++k) {
								if(!(k > j && k < i)) {
									ret.values[k] = cs.values[k];
								}
								else if(!done) {
									done = 1;
								}
							}
						}
					}
				}
			} else {
				if(j != i && j != i+1) {
					if(
					((distance(cs.values[i], cs.values[i+1])) + (distance(cs.values[j], cs.values[j+1])))
					>
					((distance(cs.values[i], cs.values[j])) + (distance(cs.values[i+1], cs.values[j+1])))
					) {
						ret.values[j] = cs.values[i+1];
						ret.values[i+1] = cs.values[j];
						if(i == j) {
							for(int k=0; k<cs.n; ++k) {
								if(k!=j && k != i+1) {
									ret.values[k] = cs.values[k];
								}
							}
						}
						else if(i<j){
							int done = 0;
							for(int k=0; k<cs.n; ++k) {
								if(!(k > i && k < j)) {
									ret.values[k] = cs.values[k];
								}
								else if(!done) {
									int cpt=0;
									for(int l=j; l>(j-i)/2; --l) {
										ret.values[cpt] = cs.values[l];
										cpt++;
									}
									done = 1;
								}
							}
						}
						else {
							int done = 0;
							for(int k=0; k<cs.n; ++k) {
								if(!(k > j && k < i)) {
									ret.values[k] = cs.values[k];
								}
								else if(!done) {
									done = 1;
								}
							}
						}
					}
				}
			}
		}
	}

	return ret;
}
