#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "fifo.h"

Cities initialSolution(const Cities);

double resolve(const Cities solution);

Cities meilleur_voisin(const Cities sol);

Cities steepest_hill_climbing(Cities cs, const int MAX_choix, const int MAX_essais);

Cities* voisins_non_tabou(const Cities cs, const Queue* tabou);

Cities meilleur_voisin_non_tabou(Cities* cs_vec);

Cities tabou(const Cities cs, const int max_list_size, const int nb_depl_max);

Cities meilleur_voisin_2_opt(const Cities cs);
