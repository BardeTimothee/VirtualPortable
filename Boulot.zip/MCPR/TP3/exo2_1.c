#include <stdio.h>
#include <string.h> /* strerror */
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>

#define NB_MAX_JOUEUR 10
#define LOCK 1

int Terrain_oqp;
int nbJoueurAtt;
int nbJoueurPres;
int nbJoueur;

pthread_cond_t Joueur = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void init(){
	Terrain_oqp = 0;
	nbJoueurAtt = 0;
	nbJoueurPres = 0;
}

void thdErreur(int codeErr, char *msgErr, void *codeArret) {
/*---------------------------------------------------------------------*/
  fprintf(stderr, "%s: %d soit %s \n", msgErr, codeErr, strerror(codeErr));
  pthread_exit(codeArret);
}

void demanderJouer(int *monNum){
	pthread_mutex_lock(&mutex);
	nbJoueurAtt++;
	printf("Terrain oqp : %d NbJoueurAtt : %d \n", Terrain_oqp, nbJoueurAtt);
	
	while (Terrain_oqp == 1 || nbJoueurAtt == 0){
		pthread_cond_wait(&Joueur, &mutex);
	}
	nbJoueurAtt--;
	printf(" * * *Joueurs %d commence à jouer \n", monNum);
	if (Terrain_oqp == 0){
		Terrain_oqp = 1;
		printf(" * * *Terrain oqp : %d NbJoueurAtt : %d \n", Terrain_oqp, nbJoueurAtt);
		pthread_cond_signal(&Joueur);
		nbJoueurPres = 2;
		printf(" * * *NbJoueurPres : %d \n",nbJoueurPres);
	}
	pthread_mutex_unlock(&mutex);
}

void arreterJouer(){
	pthread_mutex_lock(&mutex);
	nbJoueurPres--;
	if (nbJoueurPres == 0){
		Terrain_oqp = 0;
		if (nbJoueurAtt >= 2)
			pthread_cond_signal(&Joueur);
	}
	pthread_mutex_unlock(&mutex);
}

void *threadJoueur(void *arg){
	int *monNum = (int *)arg;
	int key = 0;
	
	printf("Joueurs %d déclarer, prêt à jouer \n", monNum);
	demanderJouer(monNum);
	while (key != LOCK) key = rand()%1000000;
	arreterJouer();
	printf("Joueurs %d à fini de jouer \n", monNum);
}

int main(int argc, char **argv)
{
	pthread_t lesJoueurs[NB_MAX_JOUEUR];
	int rangJoueurs[NB_MAX_JOUEUR];
	int etat;
	
	init();
	
	if (argc != 2) {
		printf("Usage: %s <Nb Joueurs <= %d> \n", 
            argv[0], NB_MAX_JOUEUR);
		exit(1);
	}

	nbJoueur = atoi(argv[1]);
	
	for (int i = 0; i < nbJoueur; i++) {
		rangJoueurs[i] = i;
		if ((etat = pthread_create(&lesJoueurs[i], NULL,
					threadJoueur, &rangJoueurs[i])) != 0)
			thdErreur(etat, "Creation Joueurs", NULL);
  }

  /* Attente de la fin des threads */
	for (int i = 0; i < nbJoueur; i++) 
		if ((etat = pthread_join(lesJoueurs[i], NULL)) != 0)
			thdErreur(etat, "Join lecteurs", NULL);
			
			
	return 0;
	printf ("\nFin de l'execution du main \n");
}

