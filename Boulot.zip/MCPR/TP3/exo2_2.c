#include <stdio.h>
#include <string.h> /* strerror */
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>

#define NB_MAX_JOUEUR 10
#define NB_MAX_ARBITRE 10
#define LOCK 1

int Terrain_oqp;
int nbJoueurAtt;
int nbJoueurPres;
int nbJoueur;
int nbArbitreAtt;
int nbArbitrePres;
int nbArbitre;

pthread_cond_t Joueur = PTHREAD_COND_INITIALIZER;
pthread_cond_t Arbitre = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void init(){
	Terrain_oqp = 0;
	nbJoueurAtt = 0;
	nbJoueurPres = 0;
}

void thdErreur(int codeErr, char *msgErr, void *codeArret) {
/*---------------------------------------------------------------------*/
  fprintf(stderr, "%s: %d soit %s \n", msgErr, codeErr, strerror(codeErr));
  pthread_exit(codeArret);
}

void demanderJouer(int *monNum){
	pthread_mutex_lock(&mutex);
	nbJoueurAtt++;
	printf("Terrain oqp : %d NbJoueurAtt : %d \n", Terrain_oqp, nbJoueurAtt);
	
	while (Terrain_oqp == 1 || nbJoueurAtt == 0 || nbArbitreAtt == 0){
		pthread_cond_wait(&Joueur, &mutex);
	}
	nbJoueurAtt--;
	printf(" * * *Joueurs %d commence à jouer \n", monNum);
	if (Terrain_oqp == 0){
		Terrain_oqp = 1;
		printf(" * * *Terrain oqp : %d NbJoueurAtt : %d \n", Terrain_oqp, nbJoueurAtt);
		pthread_cond_signal(&Joueur);
		pthread_cond_signal(&Arbitre);
		nbJoueurPres = 2;
		printf(" * * *NbJoueurPres : %d \n",nbJoueurPres);
	}
	pthread_mutex_unlock(&mutex);
}

void arreterJouer(){
	pthread_mutex_lock(&mutex);
	nbJoueurPres--;
	if (nbJoueurPres == 0){
		Terrain_oqp = 0;
		if (nbJoueurAtt >= 2 && nbArbitreAtt >= 1)
			pthread_cond_signal(&Arbitre);
	}
	pthread_mutex_unlock(&mutex);
}

void demanderArbitre() {
	pthread_mutex_lock(&mutex);
	nbArbitreAtt++;
	while (Terrain_oqp == 1 || nbJoueurAtt < 2){
		pthread_cond_wait(&Arbitre, &mutex);
	}
	nbArbitreAtt--;
	nbArbitrePres++;
	if (Terrain_oqp == 0){
		Terrain_oqp = 1;
		pthread_cond_signal(&Joueur);
		pthread_cond_signal(&Joueur);
		nbArbitrePres = 1;
	}
	pthread_mutex_unlock(&mutex);
}

void arreterArbitre() {
	pthread_mutex_lock(&mutex);
	nbArbitrePres--;
	if (nbJoueurPres == 0 && nbArbitrePres == 0){
		Terrain_oqp = 0;
		if (nbJoueurAtt >=2 && nbArbitreAtt >=1)
			pthread_cond_signal(&Arbitre);
	}
	pthread_mutex_unlock(&mutex);
}

void *threadArbitre(void *arg){
	int *monNum = (int *)arg;
	int key = 0;
	
	printf("Arbitre %d déclarer, prêt à surveiller \n", monNum);
	demanderArbitre();
	while (key != LOCK) key = rand()%1000000;
	arreterArbitre();
	printf("Arbitre %d à fini de surveiller \n", monNum);
}

void *threadJoueur(void *arg){
	int *monNum = (int *)arg;
	int key = 0;
	
	printf("Joueurs %d déclarer, prêt à jouer \n", monNum);
	demanderJouer(monNum);
	while (key != LOCK) key = rand()%1000000;
	arreterJouer();
	printf("Joueurs %d à fini de jouer \n", monNum);
}

int main(int argc, char **argv)
{
	pthread_t lesJoueurs[NB_MAX_JOUEUR];
	int rangJoueurs[NB_MAX_JOUEUR];
	pthread_t lesArbitres[NB_MAX_ARBITRE];
	int rangArbitres[NB_MAX_ARBITRE];
	int etat;
	
	init();
	
	if (argc != 3) {
		printf("Usage: %s <Nb Joueurs <= %d>  <Nb arbitres <= %d > \n", 
            argv[0], NB_MAX_JOUEUR, NB_MAX_ARBITRE);
		exit(1);
	}

	nbJoueur = atoi(argv[1]);
	nbArbitre = atoi(argv[2]);
	
	for (int i = 0; i < nbJoueur; i++) {
		rangJoueurs[i] = i;
		if ((etat = pthread_create(&lesJoueurs[i], NULL,
					threadJoueur, &rangJoueurs[i])) != 0)
			thdErreur(etat, "Creation Joueurs", NULL);
	}
	
	for (int i = 0; i < nbArbitre; i++) {
		rangArbitres[i] = i;
		if ((etat = pthread_create(&lesArbitres[i], NULL,
					threadArbitre, &rangArbitres[i])) != 0)
			thdErreur(etat, "Creation Arbitres", NULL);
	}

  /* Attente de la fin des threads */
	for (int i = 0; i < nbJoueur; i++) 
		if ((etat = pthread_join(lesJoueurs[i], NULL)) != 0)
			thdErreur(etat, "Join Joueurs", NULL);
			
	for (int i = 0; i < nbArbitre; i++) 
		if ((etat = pthread_join(lesArbitres[i], NULL)) != 0)
			thdErreur(etat, "Join Arbitres", NULL);
			
			
	return 0;
	printf ("\nFin de l'execution du main \n");
}

