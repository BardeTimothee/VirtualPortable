// Hyp : il n'y a que deux types de messages

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#define NB_FOIS_PROD_MAX   10
#define NB_FOIS_CONSO_MAX  10

#define NB_PROD_MAX   20
#define NB_CONSO_MAX  20

#define NB_CASES_MAX  20

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
	char info[80];
	int  type;
	int  rangProd;
} TypeMessage;

typedef struct {                // Parametre des threads
	int rang;
	int typeMsg;
	int nbActions;
} Parametres;


// Moniteur M {
// var etats + partagees

typedef struct {
	TypeMessage buffer[NB_CASES_MAX];  // Buffer
	int nbCasesPleines;
	int iDepot;                        // Indice prochain depot
	int iRetrait;                      // Indice prochain retrait
} RessourceCritique;

RessourceCritique resCritiques; // Modifications donc conflits possibles
int nbCases;                    // Taille effective du buffer
int typeDernierMessage;
int nbProd;

// var conditions
pthread_cond_t peutDeposer[2] = PTHREAD_COND_INITIALIZER;
pthread_cond_t peutRetirer = PTHREAD_COND_INITIALIZER;

/*--------------------------------------------------*/
void initialiserVarPartagees (void) {
	int i;

	/* Le buffer, les indices et le nombre de cases pleines */
	resCritiques.nbCasesPleines = 0;
	resCritiques.iDepot = 0;
	resCritiques.iRetrait = 0;
	typeDernierMessage = 1;
	for (i = 0; i < nbCases; i++) {
		strcpy(resCritiques.buffer[i].info, "Message vide");
		resCritiques.buffer[i].type = 0;
		resCritiques.buffer[i].rangProd = -1;
	}
}

//services de synchro

/*--------------------------------------------------*/
void depot (TypeMessage leMessage) {
	strcpy(resCritiques.buffer[resCritiques.iDepot].info, leMessage.info);
	resCritiques.buffer[resCritiques.iDepot].type = leMessage.type;
	resCritiques.buffer[resCritiques.iDepot].rangProd = leMessage.rangProd;
	resCritiques.iDepot = (resCritiques.iDepot + 1) % nbCases;
	#ifdef TRACE
		afficherBuffer();
	#endif
}

/*--------------------------------------------------*/
void retrait (TypeMessage *leMessage) {
	strcpy(leMessage->info, resCritiques.buffer[resCritiques.iRetrait].info);
	leMessage->type = resCritiques.buffer[resCritiques.iRetrait].type;
	leMessage->rangProd = resCritiques.buffer[resCritiques.iRetrait].rangProd;
	resCritiques.iRetrait = (resCritiques.iRetrait + 1) % nbCases;
	#ifdef TRACE
		afficherBuffer();
	#endif
}

/*--------------------------------------------------
 * Correspondra au service du moniteur vu en TD
 * La synchronisation sera ajoutee dans cette operation
 * */
void deposer (TypeMessage leMessage) {
	pthread_mutex_lock(&mutex);
	while(resCritiques.nbCasesPleines == nbCases || leMessage.type == typeDernierMessage)
		pthread_cond_wait(&peutDeposer[leMessage.type], &mutex);

	depot(leMessage);
	resCritiques.nbCasesPleines++;
	typeDernierMessage = leMessage.type;
	pthread_cond_signal(&peutRetirer);

	if(resCritiques.nbCasesPleines != nbCases)
		pthread_cond_signal(&peutDeposer[(typeDernierMessage+1)%2]);

	pthread_mutex_unlock(&mutex);
}

/*--------------------------------------------------
 * Correspondra au service du moniteur vu en TD
 * La synchronisation sera ajoutee dans cette operation
 * */
void retirer (TypeMessage *leMessage) {
	pthread_mutex_lock(&mutex);
	while(resCritiques.nbCasesPleines == 0)
		pthread_cond_wait(&peutRetirer, &mutex);

	retrait(leMessage);
	resCritiques.nbCasesPleines--;
	pthread_cond_signal(&peutDeposer[(leMessage->type+1)%2]);
	pthread_mutex_unlock(&mutex);
}
//} FIN MONITEUR

/*---------------------------------------------------------------------*/
/* codeErr : code retournee par une primitive
 * msgErr  : message d'erreur personnalise
 * valErr  : valeur retournee par le thread
 */
void thdErreur(int codeErr, char *msgErr, int valeurErr) {
	int *retour = malloc(sizeof(int));
	*retour = valeurErr;
	fprintf(stderr, "%s: %d soit %s \n", msgErr, codeErr, strerror(codeErr));
	pthread_exit(retour);
}

/*--------------------------------------------------*/
void afficherBuffer (void) {
	int i;

	printf("[ ");
	for (i = 0; i < nbCases; i++) {
		printf("[T%d] %s (de %d), ",
			resCritiques.buffer[i].type,
			resCritiques.buffer[i].info,
			resCritiques.buffer[i].rangProd);
	}
	printf("]\n");
}


/*--------------------------------------------------*/
void * producteur (void *arg) {
	int i;
	TypeMessage leMessage;
	Parametres *param = (Parametres *)arg;

	srand(pthread_self());

	for (i = 0; i < param->nbActions; i++) {
		sprintf (leMessage.info, "%s %d %s %d", "bonjour num ", i, "de prod ", param->rang);
		leMessage.type = param->typeMsg;
		leMessage.rangProd = param->rang;

		deposer(leMessage);
		printf("\tProd %d : Message depose = [T%d] %s (de %d)\n",
			param->rang, leMessage.type, leMessage.info, leMessage.rangProd);

		//usleep(rand()%(100 * param->rang + 100));
	}
}

/*--------------------------------------------------*/
void * consommateur (void *arg) {
	int i;
	TypeMessage unMessage;
	Parametres *param = (Parametres *)arg;

	srand(pthread_self());

	for (i = 0; i < param->nbActions; i++) {
		retirer(&unMessage);
		printf("\t\tConso %d : Message lu = [T%d] %s (de %d)\n",
	 		param->rang, unMessage.type, unMessage.info, unMessage.rangProd);

		//usleep(rand()%(100 * param->rang + 100));
	}
}

/*--------------------------------------------------*/
int main(int argc, char *argv[]) {
	int i, etat;
	int nbThds, nbConso, nbFoisProd, nbFoisConso;
	Parametres paramThds[NB_PROD_MAX + NB_CONSO_MAX];
	pthread_t idThdProd[NB_PROD_MAX], idThdConso[NB_CONSO_MAX];

	if (argc != 6) {
		printf ("Usage: %s <Nb Prod <= %d> <Nb Productions <= %d> <Nb Conso <= %d> <Nb Consommations <= %d> <Nb Cases <= %d> \n",
						 argv[0], NB_PROD_MAX, NB_FOIS_PROD_MAX, NB_CONSO_MAX, NB_FOIS_CONSO_MAX, NB_CASES_MAX);
		exit(2);
	}

	// Initialisation variables
	nbProd  = atoi(argv[1]);
	if (nbProd > NB_PROD_MAX)
		nbProd = NB_PROD_MAX;
	nbFoisProd = atoi(argv[2]);
	if(nbFoisProd > NB_FOIS_PROD_MAX)
		nbFoisProd = NB_FOIS_PROD_MAX;
	nbConso = atoi(argv[3]);
	if (nbConso > NB_CONSO_MAX)
		nbConso = NB_CONSO_MAX;
	nbFoisConso = atoi(argv[4]);
	if(nbFoisConso > NB_CONSO_MAX)
		nbFoisConso = NB_FOIS_CONSO_MAX;
	nbThds = nbProd + nbConso;
	nbCases = atoi(argv[5]);
	if (nbCases > NB_CASES_MAX)
		nbCases = NB_CASES_MAX;

	if(nbProd*nbFoisProd > nbConso*nbFoisConso && nbCases < nbProd*nbFoisProd) {
		fprintf(stderr, "Erreur : Impossible d'atteindre la fin du programme\n");
		fprintf(stderr, "Trop de productions par rapport au nombre de consommation et à la taille du buffer\n");
		exit(1);
	}

	if(nbProd%2 != 0 && nbConso*nbFoisConso >= nbProd*nbFoisProd) {
		fprintf(stderr, "Erreur : Impossible d'atteindre la fin du programme\n");
		fprintf(stderr, "Nombre de différent de type de message et trop de retraits\n");
		exit(2);
	}

	initialiserVarPartagees();

	/* Creation des nbProd producteurs et nbConso consommateurs */
	for (i = 0; i <  nbThds; i++) {
		if (i < nbProd) {
			paramThds[i].typeMsg = i%2;
			paramThds[i].rang = i;
			paramThds[i].nbActions = nbFoisProd;
			if ((etat = pthread_create(&idThdProd[i], NULL, producteur, &paramThds[i])) != 0)
				thdErreur(etat, "Creation producteur", etat);
			#ifdef TRACE
				printf("Creation thread prod %lu de rang %d -> %d/%d\n", idThdProd[i], i, paramThds[i].rang, nbProd);
			#endif
		}
		else {
			paramThds[i].rang = i - nbProd;
			paramThds[i].nbActions = nbFoisConso;
			if ((etat = pthread_create(&idThdConso[i-nbProd], NULL, consommateur, &paramThds[i])) != 0)
				thdErreur(etat, "Creation consommateur", etat);
			#ifdef TRACE
				printf("Creation thread conso %lu de rang %d -> %d/%d\n", idThdConso[i-nbProd], i, paramThds[i].rang, nbConso);
			#endif
		}
	}

	/* Attente de la fin des threads */
	for (i = 0; i < nbProd; i++) {
		if ((etat = pthread_join(idThdProd[i], NULL)) != 0)
			thdErreur(etat, "Join threads producteurs", etat);
		#ifdef TRACE
			printf("Fin thread producteur de rang %d\n", i);
		#endif
	}

	for (i = 0; i < nbConso; i++) {
		if ((etat = pthread_join(idThdConso[i], NULL)) != 0)
			thdErreur(etat, "Join threads consommateurs", etat);
		#ifdef TRACE
			printf("Fin thread consommateur de rang %d\n", i);
		#endif
	}

	#ifdef TRACE
		printf ("\nFin de l'execution du main \n");
	#endif

	return 0;
}
