#include "Expr.hpp"


Expr::Expr(const char *str) {
	expression = strdup(str);
}

char* Expr::getExpression() {
	return expression;
}

void Expr::setExpression(string str) {
	expression = strdup(str.c_str());
}

float Expr::eval() {
	vector<string> tokens = this->split(this->expression);
	queue<ExprToken> exprTokens = this->convertToRPN(tokens);
	stack<ExprToken> resStack;

	while(!exprTokens.empty()) {
		ExprToken token = exprTokens.front();
		exprTokens.pop();

		// digit
		if(
			token.op != '+'
			&& token.op != '-'
			&& token.op != '*'
			&& token.op != '/'
		) resStack.push(token);

		// op
		else {
			float a = resStack.top().r;
			resStack.pop();
			float b = resStack.top().r;
			resStack.pop();

			switch(token.op) {
				case('+'):
					b += a;
					break;
				case('-'):
					b -= a;
					break;
				case('*'):
					b *= a;
					break;
				case('/'):
					b /= a;
			}

			ExprToken result;
			result.r = b;
			resStack.push(result);
		}
	}

	return resStack.top().r;
}

void Expr::print() {
	cout << "Affichage de l'expression :" << endl;

	int i{0};
	while(expression[i] != '\0') {
		cout << expression[i];
		++i;
	}
	cout << endl;
}

// Unused
vector<string> Expr::split(const string& s, const char delim) {
	stringstream ss{s};
	vector<string> tokens;

	while(!ss.eof()) {
		string buffer;
		getline(ss, buffer, delim);
		tokens.push_back(buffer);
	}

	return tokens;
}

vector<string> Expr::split(const string& s) {
	vector<string> tokens;
	string buffer;

	for(unsigned int i{0}; i<s.size(); ++i) {
		if(s[i] == '+'
			|| s[i] == '-'
			|| s[i] == '*'
			|| s[i] == '/'
			|| s[i] == '('
			|| s[i] == ')'
			) {
			tokens.push_back(buffer);
			buffer = s[i];
			tokens.push_back(buffer);
			buffer.clear();
		}
		else buffer.push_back(s[i]);
	}
	tokens.push_back(buffer);

	return tokens;
}

queue<ExprToken> Expr::convertToRPN(const vector<string> tokens) {
	stack<ExprToken> operators;
	queue<ExprToken> exprTokens;

	for(const string& token : tokens) {
		int i{0};
		bool digit{true};
		while(token[i] != '\0' && digit) {
			locale loc;
			if(token[i] != '.' && !isdigit(token[i], loc)) digit = false;
			++i;
		}

		try {
			// litteral
			if(digit) {
				ExprToken litt;
				litt.r = atof(token.c_str());
				exprTokens.push(litt);
			}

			// operateur
			else if((token[0] == '+' || token[0] == '-' || token[0] == '*' || token[0] == '/') && token[1] == '\0') {
				ExprToken oper;
				oper.op = token[0];

				if(oper.op == '+' || oper.op == '-') {
					if(!operators.empty()) {
						bool end{false};
						while(!end && (operators.top().op == '*' || operators.top().op == '/')) {
							exprTokens.push(operators.top());
							operators.pop();
							if(operators.empty()) end = true;
						}
					}
				}
				operators.push(oper);
			}

			// erreur
			else {
				throw string("Erreur de syntaxe");
			}
		} catch(string const& error) {
			cerr << error << endl;
			exit(1);
		}
	}

	// vider pile dans sortie
	while(!operators.empty()) {
		exprTokens.push(operators.top());
		operators.pop();
	}

	return exprTokens;
}
