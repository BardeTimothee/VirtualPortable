#pragma once
#include <iostream>
#include <vector>
#include <string.h>
#include <sstream>
#include <stack>
#include <queue>
#include <locale>

using namespace std;

union ExprToken {
	float r;
	char op;
};

class Expr {
	public:
		// Construit une expression a partir du texte
		Expr(const char *str);

		// Retourne *expression
		char* getExpression();

		// Mets a jour *expression
		void setExpression(string str);

		// Retourne la valeur de l'expression
		float eval();

		// Affiche l'expression
		void print();

		// Split le contenu de l'expression selon delimiteur (supprime delimiteurs)
		vector<string> split(const string& s, char delim);

		// split le contenu de l'expression non separee par des espaces en tokens
		vector<string> split(const string& s);

	private:
		char *expression;

		// Transforme l'expression en notation RPN
		// WARNING : ne supporte pas les parentheses
		queue<ExprToken> convertToRPN(vector<string> tokens);
};
