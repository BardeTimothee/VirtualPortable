#include "Program.hpp"



Program::Program(queue<Expr> _expressions, bool *_flags) {
  expressions = _expressions;
  flags = _flags;
}

bool Program::keyword(const string str) {
  char c = str[0];
  locale loc;
  if(!isdigit(c, loc) && c != '+' && c != '-' && c != '*' && c != '/') return true;
  return false;
}

bool Program::func(const string str) {
	char c = str[0];
	if (!isdigit(c) && c != '+' && c != '-' && c != '*' && c != '/') return true;
	return false;
}

void Program::exec() {
  int i{0};
  while(!expressions.empty()) {
    Expr expr(expressions.front());
    expressions.pop();
    float res;

    vector<string> parts = expr.split(expr.getExpression(), '=');
    // s'il n'y a pas de =
    if(parts.size() == 1) {
      if(keyword(parts.front())) {
        try {
          if(evaluations.count(parts.front())) res = evaluations.find(parts.front())->second;
          else throw string("Error : undeclared var used");
        } catch(string const& error) {
          cerr << error << endl;
          exit(2);
        }
      } else if (func(parts.front())) {
		  
	  }
      else res = expr.eval();
    }

    // il y a un =
    else {
      string key = parts.front();
      stack<string> interStack;

      vector<string> temp = expr.split(parts.back());
      while(!temp.empty()) {
        if(keyword(temp.back())) {
          float valueKeyword;

          try {
            if(evaluations.count(temp.back())) valueKeyword = evaluations.find(temp.back())->second;
            else throw string("Error : undeclared var used");
          } catch(string const& error) {
            cerr << error << endl;
            exit(2);
          }

          ostringstream valueKeywordToString;
          valueKeywordToString << valueKeyword;

          interStack.push(valueKeywordToString.str());
        }
        else interStack.push(temp.back());

        temp.pop_back();
      }

      string newExpr;
      while(!interStack.empty()) {
        newExpr += interStack.top();
        interStack.pop();
      }
      expr.setExpression(newExpr);
      res = expr.eval();
      evaluations.insert(pair<string,float>(key, res));
    }

    if(flags[i]) cout << res << endl;
    ++i;
  }
}
