#pragma once
#include <map>
#include "Expr.hpp"

using namespace std;

class Program {
  protected:
    queue<Expr> expressions;
    bool *flags;
    map<string, float> evaluations;

    // renvoie true si le string est un mot clé
    bool keyword(const string);

  public:
    Program(queue<Expr> expressions, bool *flags);
    void exec();
};
