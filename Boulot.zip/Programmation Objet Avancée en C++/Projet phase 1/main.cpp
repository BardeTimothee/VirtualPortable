#include <iostream>
#include "Expr.hpp"
#include "Program.hpp"


int main()
{
  cout << "Entrez vos expressions" << endl;
  cout << "Terminez par ';' si vous ne souhaitez pas voir le resultat" << endl;
  cout << "Entrez 'end' pour terminer la saisie" << endl;

	queue<Expr> expressions;
	string in;
	int i{0};
	bool flags[20];

  while(in.compare("end")) {
    cin >> in;

		if(in.compare("end")) {
			if(in.back() == ';') {
				flags[i] = false;
				in.pop_back();
			}
			else flags[i] = true;
	    Expr expr(in.c_str());
	    expressions.push(expr);
			++i;
		}
  }
	cout << endl;
	
	Program prog1(expressions, flags);
	prog1.exec();

	return 0;
}
