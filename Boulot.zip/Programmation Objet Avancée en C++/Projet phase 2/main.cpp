#include "tokenstream.h"
#include "program.h"

#include <sstream>  // String stream


int main(int argc, char *argv[]) {

    std::string test_expr[]{
		"sqrt(25)",//0
		"sqrt(24+1)",//1
		"pow(2,3)",//2
		"pow((1+1),(2+1))",//3
		"pow(1+1, 3)",//4 // PROBLEME ICI
		"deux=1+1;\npow(deux,3)\npow((1+1),3)", // 5 // Declarer alias avant, ou mettre entre parentheses
		"res1 = sin(log(5)+3);\nlog5 = log(5);\nlog53 = log5+3;\nres2 = sin(log53);",// 6 // PROBLEME ICI
		"res1 = sin(((log(5))+3));\nlog5 = log(5);\nlog53 = log5+3;\nres2 = sin(log53);",// 7 // Need parenthese pour pas de souci
		"hypot(3,2)", // 8
		"lerp(1,3,0.5)", // 9
		"cible=49;\npolynome(3,1,2,3,4,2)", // 10
		"2+pow(1)+1"
	};
    constexpr auto num_test = std::extent<decltype(test_expr)>::value;

    // Input token stream
    TokenStream ts{std::cin};


    switch (argc) {
        case 1:
            std::cout << "Enter your expression (<Ctrl-D> to terminate) : " << std::endl;
            break;
        case 2: {
            auto nt = decltype(num_test)(std::atoi(argv[1]));
            if (nt < num_test) {
                std::cout << "----------------" << std::endl << "Executing test " << nt << " : " << std::endl
                          << test_expr[nt]
                          << std::endl << "----------------" << std::endl;
                ts.setInput(new std::istringstream{test_expr[nt]});
            } else {
                std::cout << "Test " << nt << " unavailable !" << std::endl;
                return 1;
            }
        }
        break;
        default:
            std::cerr << "Too many arguments !" << std::endl;
            return 1;
    }

    try {
        Program prog{ts};

        // Evaluate the program
        double result = prog.eval();

        std::cout <<  "----------------" << std::endl << "Program result is " << result << std::endl;

        std::cout << "----------------" << std::endl;
        prog.dump_memory();

    } catch (const TokenStream::Error &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Program::Error &e) {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}
