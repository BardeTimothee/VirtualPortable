#include "tokenstream.h"
#include <sstream>  // String stream


/// Returns true if the token is a litteral.
bool Token::isLiteral() const {
    return kind == Kind::number;
}

bool Token::isIdentifier() const {
    return kind == Kind::name;
}

/// Returns true if the token is a litteral.
bool Token::isOperator() const {
    return (kind == Kind::plus) || (kind == Kind::minus) || (kind == Kind::mul) || (kind == Kind::div);
}

/// Returns true if the token is a separator (\n, ;, next or end).
bool Token::isSeparator() const {
    return (kind == Kind::end) || (kind == Kind::print) || (kind == Kind::next);
}

// Returns true if the token is a unary function
bool Token::isUnaryFunction() const {//
	return (kind == Kind::sin || kind == Kind::cos || kind == Kind::tan || kind == Kind::sqrt || kind == Kind::log || kind == Kind::exp); //
}//

/// Returns true if the token is a binary function.
bool Token::isBinaryFunction() const {//
	return (kind == Kind::pow || kind == Kind::hypot);
}

/// Returns true if the token is a ternary function.
bool Token::isTernaryFunction() const {//
	return (kind == Kind::lerp);
}

/// Returns true if the token is a multinary function.
bool Token::isMultinaryFunction() const {//
	return (kind == Kind::polynome);
}

int Token::compare(const Token &other) const {
    if (kind == Kind::minus || kind == Kind::plus)
		if (other.kind == Kind::minus || other.kind == Kind::plus)
			return 0;
		else
			return -1;
    else if (other.kind == Kind::minus || other.kind == Kind::plus)
        return 1;
    else
        return 0;
}


std::ostream &operator<<(std::ostream &os, const Token &t) {
    switch (t.kind) {
        case Kind::name:
            os << t.string_value << ' ';
            break;
        case Kind::number:
            os << t.number_value << ' ';
            break;
        case Kind::end:
        case Kind::print:
            os << std::endl;
            break;
        case Kind::next:
            os << static_cast<char>(t.kind);
            break;
        case Kind::assign:
            os << t.string_value << '=' << ' ';
            break;
		case Kind::comma:
			os << ',';
			break;

        case Kind::plus:
        case Kind::minus:
        case Kind::mul:
        case Kind::div:
		case Kind::sin:  //
		case Kind::cos://
		case Kind::tan://
		case Kind::sqrt://
		case Kind::log://
		case Kind::exp://
		case Kind::pow://
		case Kind::hypot://
		case Kind::lerp://
		case Kind::polynome://
        case Kind::lp:
        case Kind::rp:
            os << static_cast<char>(t.kind) << ' ';
            break;
        default:
            throw TokenStream::Error("Undefined Token ");
    }
    return os;
}

double Token::operate(double a1, double a2) const {//
    switch (kind) {
        case Kind::plus:
            return a1 + a2;
        case Kind::minus:
            return a1 - a2;
        case Kind::mul:
            return a1 * a2;
        case Kind::div:
            return a1 / a2;
		case Kind::pow://
			return pow(a1, a2);//
		case Kind::hypot://
			return hypot(a1, a2);//
        default:
            throw TokenStream::Error("Bad operator  -- " + string_value);
    }
}

double Token::operateUnaryFunction(double a) const { //
	switch(kind) { //
		case Kind::sin://
			return sin(a);//
		case Kind::cos://
			return cos(a);
		case Kind::tan://
			return tan(a);
		case Kind::sqrt://
			return sqrt(a);
		case Kind::log://
			return log(a);
		case Kind::exp://
			return exp(a);
		default://
			throw TokenStream::Error("Bad unary function -- " + string_value);//
	}//
}//

double Token::operateTernaryFunction(double a1, double a2, double a3) const {//
	switch(kind) {
		case Kind::lerp:
			if (a3 < 0 || a3 > 1)
				// Mauvais stream error
				throw TokenStream::Error("Bad value coefficient : must be between 0 et 1.");
			return a1 + a3 * (a2 - a1);
		default:
			throw TokenStream::Error("Bad operator  -- " + string_value);
	}
}

double Token::operateMultinaryFunction(std::vector<double> args) const {//
	double x{args[args.size()-1]};
	double sum = args[0];
	for (unsigned int i=1; i<args.size()-1; ++i)
		sum += args[i] * (pow(x,i));
	return sum;
}

Token TokenStream::get() {
    char ch{0};

    do {
        if (!ip->get(ch))
            return ct = {Kind::end};
    } while (ch != '\n' && std::isspace(ch));

    switch (ch) {
        case ';':
            return ct = {Kind::next};
        case '\n':
            return ct = {Kind::print};
        case '*': case '/':
        case '+': case '-':
        case '(': case ')':
        case '=':
            return ct = {static_cast<Kind>(ch)};
        case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
        case '.':
            // put the first digit (or .) back into the input stream
            ip->putback(ch);
            // read the number into ct
            *ip >> ct.number_value;
            ct.kind = Kind::number;
            return ct;
		case ',':
			ct.kind = Kind::comma;
			return ct;
		default:
            // name, name =, or error
            if (std::isalpha(ch)) {
                ct.string_value = {ch};
                while (ip->get(ch) && std::isalnum(ch))
                    ct.string_value += ch;
                ip->putback(ch);
				// SWITCH IMPOSSIBLE
				if (ct.string_value == "sin")//
					ct.kind = Kind::sin;//
				else if (ct.string_value == "cos")//
					ct.kind = Kind::cos;//
				else if (ct.string_value == "tan")//
					ct.kind = Kind::tan;//
				else if (ct.string_value == "sqrt")//
					ct.kind = Kind::sqrt;//
				else if (ct.string_value == "log")//
					ct.kind = Kind::log;//
				else if (ct.string_value == "exp")//
					ct.kind = Kind::exp;//
				else if (ct.string_value == "pow")//
					ct.kind = Kind::pow;//
				else if (ct.string_value == "hypot")//
					ct.kind = Kind::hypot;//
				else if (ct.string_value == "lerp")//
					ct.kind = Kind::lerp;//
				else if (ct.string_value == "polynome")//
					ct.kind = Kind::polynome;//
				else//
					ct.kind = Kind::name;
                return ct;
            } else {
                ip->putback(ch);
                std::stringstream error;
                error << "Bad Token (" << ch << ")";
                throw TokenStream::Error(error.str());
            }
    }
}
