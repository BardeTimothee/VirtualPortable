#include "tokenstream.h"
#include "program.h"

#include <sstream>  // String stream


int main(int argc, char *argv[]) {

    std::string test_expr[]{
		"lerp(1,3,0.5)", // 0
		"l=lerp(1,3)", // 1
		"l=lerp(1,3);\nl(0.5)\nlerp(1,3,0.5)", // 2
		// "cible=49;\npolynome(3,1,2,3,4,2)", // 4
		// "l=lerp(1,3);\nl(0.5)\nlerp(1,3,0.5)", // 5
		// "polynome(3,1,2,3,4)", // 6
		// "cible=49;\np=polynome(3,1,2,3,4);\np(2)" // 7
	};
    constexpr auto num_test = std::extent<decltype(test_expr)>::value;

    // Input token stream
    TokenStream ts{std::cin};


    switch (argc) {
        case 1:
            std::cout << "Enter your expression (<Ctrl-D> to terminate) : " << std::endl;
            break;
        case 2: {
            auto nt = decltype(num_test)(std::atoi(argv[1]));
            if (nt < num_test) {
                std::cout << "----------------" << std::endl << "Executing test " << nt << " : " << std::endl
                          << test_expr[nt]
                          << std::endl << "----------------" << std::endl;
                ts.setInput(new std::istringstream{test_expr[nt]});
            } else {
                std::cout << "Test " << nt << " unavailable !" << std::endl;
                return 1;
            }
        }
        break;
        default:
            std::cerr << "Too many arguments !" << std::endl;
            return 1;
    }

    try {
        Program prog{ts};

        // Evaluate the program
        double result = prog.eval();

        std::cout <<  "----------------" << std::endl << "Program result is " << result << std::endl;

        std::cout << "----------------" << std::endl;
        prog.dump_memory();

    } catch (const TokenStream::Error &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Program::Error &e) {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}
