#include <iostream>
using namespace std;

class Complex {
private:
	float _r;
	float _i;
public:
	Complex(float r=0, float i=0) : _r{r}, _i{i} {};
	~Complex(){};
	static const Complex zero;
	inline float& real();
	inline float imag() const;
	Complex operator +(const Complex &c) const;
	Complex operator +(const float&) const;
	Complex operator -(const Complex &c) const;

	friend Complex operator + (float&, Complex&);
	friend ostream& operator <<(ostream& out, const Complex &c);
};



Complex Complex::operator + (const float& f) const {
	return Complex(_r + f, _i + f);
}

const Complex Complex::zero{0,0};

inline float& Complex::real() {
	return _r;
}

inline float Complex::imag() const { return _i; }

Complex Complex::operator +(const Complex &c) const {
	return Complex(_r + c._r, _i + c._i);
}
Complex Complex::operator -(const Complex &c) const {
	if(c._i == 0)
		throw runtime_error("Soustraction par 0");
	return Complex(_r - c._i, _i - c._i);
}

ostream& operator <<(ostream &out, const Complex &c) {
	out << c._r << " " << c._i << endl;
	return out;
}

int main() {
	const Complex x{1.f, 2.f};
	const Complex y{2.f, 1.f};
	Complex z = x + y;
	Complex w = x + Complex::zero;

	cout << z;
	w = z.operator+ (3);
	w = 3 + z;
	operator+(3, z);
	cout << w;

	return 0;
}
