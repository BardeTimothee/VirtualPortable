#include <iostream>
using namespace std;

class Complex {
private:
	float _r;
	float _i;
public:
	Complex(float r=0, float i=0) : _r{r}, _i{i} {};
	~Complex(){};
	static const Complex zero;
	inline float& real();
	inline float imag() const;
	Complex operator +(const Complex &c) const;
	Complex operator +(const float&) const;
	Complex operator -(const Complex &c) const;

	friend Complex operator + (float&, Complex&);
	friend ostream& operator <<(ostream& out, const Complex &c);
};

///////////////////////////////////////////////////////////////////////////////

class OutOfBound{};
class CVector {
public:
	CVector(unsigned size=10);
	~CVector();
	inline Complex& operator [](const unsigned i);
	void push_back(const Complex& c) throw(OutOfBound);
	friend ostream& operator <<(ostream& out, const CVector& cv);

	class CVIterator {
	public:
		CVIterator(CVector& cv, const unsigned i=0) : _cv{cv}, _i{i} {};
		~CVIterator() {};
		inline Complex& operator *() const;
		inline CVIterator& operator ++();
		// inline Complex& begin();
	private:
		const CVector& _cv;
		unsigned _i;
	};
private:
	int N;
	unsigned c;
	Complex *t;
};

CVector::CVector(unsigned _c) : N{0}, c{_c}, t{new Complex[_c]} {}
CVector::~CVector() { delete [] t; }
inline Complex& CVector::operator [](const unsigned i) {
	return t[i];
}
void CVector::push_back(const Complex &_c) throw(OutOfBound) {
	if(N == c) throw OutOfBound();
	else {
		t[N] = _c;
		++N;
	}
}
ostream& operator <<(ostream& out, const CVector& cv) {
	for(int i=0; i<cv.N; ++i)
		out << cv.c << endl;
	return out;
}

inline Complex& CVIterator::operator *() { return _cs[i]; }
// inline iterator& operator ++() { ++_i; return *this; }
// Complex& iterator::begin() { return _cv[0]; }

int main() {
	return 0;
}
