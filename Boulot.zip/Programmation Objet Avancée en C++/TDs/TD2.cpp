#include <iostream>
using namespace std;

class Expr {
public:
	virtual ~Expr();
	virtual float eval(float x) const =0;
	virtual void print(ostream& out) const =0;
};

class Const : public Expr {
public:
	Const(float c) : _c{c} {}
	virtual float eval(float x) { return _c; }
	virtual void print(ostream& out) { out << _c; }
private:
	float _c;
};

int main() {
	return 0;
}
