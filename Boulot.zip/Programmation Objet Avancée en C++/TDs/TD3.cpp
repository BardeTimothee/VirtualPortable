#include <iostream>
#include <vector>
using namespace std;

template<class T>
void exo21(vector<T>& v, const int nb) {
	for(int i=0; i<nb; ++i) {
		T x;
		cin >> x;
		v.push_back(x);
	}
}

// template<class T>
// void exo22(vector<T>& v) {
// 	for(auto itr = v.begin(), stop = v.end(); itr != stop; ++itr) {
// 		cout << itr;
// 	}
// }
//
// // template<class T>
// void exo22(vector<int>& v) {
// 	for(auto itr = v.begin(), stop = v.end(); itr != stop; ++itr) {
// 		cout << itr;
// 	}
// }

int main() {
	return 0;
}
