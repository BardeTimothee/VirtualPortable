#pragma once
#include <iostream>
#include <vector>
#include <string.h>
#include <sstream>
#include <stack>
#include <queue>
#include <locale>

using namespace std;

union ExprToken {
	int n;
	char op;
};

class Expr {
	public:
		// Construit une expression a partir du texte
		Expr(const char *str);

		// Retourne la valeur de l'expression
		int eval();

		// Affiche l'expression
		void print();

	private:
		char *expression;

		// Split le contenu de l'expression separee par des espaces en tokens
		// WARNING : obsolete, non compatible avec parentheses
		vector<string> split(const string& s, char delim);

		// split le contenu de l'expression non separee par des espaces en tokens
		vector<string> split(const string& s);

		// Transforme l'expression en notation RPN
		// WARNING : ne supporte pas les parentheses
		queue<ExprToken> convertToRPN(vector<string> tokens);
};
