#include <iostream>
#include "expr.hpp"


int main()
{
	Expr expr("50-50/2");
	expr.print();

	cout << endl << "Evaluation de l'expression : " << expr.eval() << endl;
	return 0;
}
