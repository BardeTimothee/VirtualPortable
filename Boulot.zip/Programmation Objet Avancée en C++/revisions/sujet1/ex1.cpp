// 80

#include <iostream>

class base {
	int arr[10];
};

class b1 : public base {};

class b2 : public base {};

class derived : public b1, public b2 {};

int main() {
	std::cout << sizeof(derived) << std::endl;
	return 0;
}
