#include <iostream>

class A {
	int i;
public:
	A(int ii=0) : i(ii) {}
	void show() {std::cout << i << std::endl;}
};

class B {
	int x;
public:
	B(int xx) : x(xx) {}
	operator A() const {return A(x);}
};

void g(A a) {
	a.show();
}

int main() {
	const B b {10};
	g(b.operator A());
	g(A(20));
	return 0;
}
