#include <stdlib.h>
#include <stdio.h>
#include <iostream>

class Test {
	int x;
public:
	void* operator new(size_t size);
	void operator delete(void*);
	Test(int i, float t = 6.8) {
		x = i;
		std::cout << "Constructor called -- " << x << " " << t << std::endl;
	}
	~Test() {
		std::cout << "Destructor called -- " << x << std::endl;
	}
};

void* Test::operator new(size_t size) {
	void *storage = malloc(size);
	std::cout << "new called " << size << "\n";
	return storage;
}

void Test::operator delete(void *p) {
	std::cout << "delete called \n";
	free(p);
}

int main() {
	Test *m = new Test(5, 3.4);
	delete m;
	Test x(10);
	return 0;
}
/*
new called
Constructor called -- 5
Destructor called -- 5
delete called
Constructor called -- 10
Destructor called -- 10
*/
