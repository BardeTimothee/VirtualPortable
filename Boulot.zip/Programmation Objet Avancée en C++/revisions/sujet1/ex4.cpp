#include <iostream>

template<int n> struct funStruct {
	static const int val = 2*funStruct<n-1>::val;
};

template<> struct funStruct<0> {
	static const int val = 1;
};

int main() {
	std::cout << funStruct<10>::val << std::endl;
	return 0;
}

/*
2^10
1024
*/
