#include <iostream>

class Test {
public:
	Test(int i);
};

Test::Test(int i) {
	std::cout<<"Constructor called \n";
}

int main() {
	std::cout << "Start \n";
	Test t1(); // wtf
	std::cout << "End \n";
	return 0;
}
