#include <iostream>

class Test {
	int &t;
public:
	Test(int &x):t(x) {}
	int getT() { return t; }
};

int main() {
	int x = 20;
	Test t1(x);
	std::cout << t1.getT() << " ";
	x = 30;
	std::cout << t1.getT() << std::endl;
	return 0;
}
