#include <iostream>

using namespace std;

template<int N>
class A {
	int arr[N];
public:
	virtual void fun() { cout << "A::fun()\n"; }
};

class B : public A<2> {
public:
	void fun() {cout << "B::fun()\n";}
};

class C : public B {};

int main() {
	B *x = new C;
	A<2> &y = *x;
	A<2> z = y;
	x->fun();
	y.fun();
	z.fun();
	return 0;
}
