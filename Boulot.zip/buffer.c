#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <asm/uaccess.h>
#include <linux/list.h>

#define LICENCE "GPL" 
#define AUTEUR "Barde Timothée" 
#define DESCRIPTION "Exemple de module Master CAMSI" 
#define DEVICE "PC"

dev_t dev;
struct cdev *my_cdev;
struct file *my_file;
int busy;
int newOpen = 0;
int MaxSize = 4;


struct s_buffer {
	int bufSize;
	char * value;
} buffer;

struct s_liste {
	struct list_head liste;
	struct s_buffer buf;
} l_buffer;

struct list_head MaListe;
LIST_HEAD(MaListe);

ssize_t Myread(struct file *f, char *buf, size_t size, loff_t *offset);
ssize_t Mywrite(struct file *f, const char *buf, size_t size, loff_t *offset);
int Myopen (struct inode * iode, struct file * fille);
int Myrelease (struct inode * iode, struct file * fille);

struct file_operations fops = {
.owner  = THIS_MODULE,
.llseek = NULL,
.read = Myread,
.write = Mywrite,
.unlocked_ioctl = NULL,
.open = Myopen,
.release = Myrelease
};

ssize_t Myread(struct file *f, char *buf, size_t size, loff_t *offset){
	struct s_liste *unElement;
	struct list_head *ptr;
	struct list_head *next;
	printk(KERN_ALERT "Read called!\n");
	int sizeToCopy;
	int cur = 0;
	
	list_for_each_safe(ptr, next, &MaListe){
			unElement = list_entry(ptr, struct s_liste, liste);
			sizeToCopy = unElement->buf.bufSize < size ? unElement->buf.bufSize : size;
			if (unElement->buf.bufSize != 0){
				if(copy_to_user(buf+cur, unElement->buf.value, sizeToCopy)==0){
					cur += sizeToCopy;
					unElement->buf.bufSize = 0;
					list_del(ptr);
					kfree(unElement);
					
				}
				else
					return -EFAULT;
			}
	}
	return cur;
}

ssize_t Mywrite(struct file *f, const char *buf, size_t size, loff_t *offset){
	size = size < MaxSize ? size : MaxSize;
	printk(KERN_ALERT "Write called!\n");
	if(newOpen == 1) {
		struct s_liste *unElement;
		struct list_head *ptr;
		struct list_head *next;
		list_for_each_safe(ptr, next, &MaListe){
			unElement = list_entry(ptr, struct s_liste, liste);
			list_del(ptr);
			kfree(unElement);
		}
	}
	
	struct s_liste *nouvelElement;
	nouvelElement = (struct s_liste *)kmalloc(sizeof(struct s_liste), GFP_KERNEL);
	INIT_LIST_HEAD(&nouvelElement->liste);
	nouvelElement->buf.value = (char *)kmalloc((size+1) * sizeof(char), GFP_KERNEL);
	nouvelElement->buf.bufSize = size - copy_from_user(nouvelElement->buf.value, buf, size);
	nouvelElement->buf.value[size] = '\0';
	list_add_tail(&nouvelElement->liste, &MaListe);
	printk(KERN_ALERT "Taille du buffer: %d \n", nouvelElement->buf.bufSize);
	printk(KERN_ALERT "Valeur du buffer : %s \n\n", nouvelElement->buf.value);
	
	newOpen = 0;
	return nouvelElement->buf.bufSize;
} 

int Myopen (struct inode * iode, struct file * fille){
	if (busy == 0){
		printk(KERN_ALERT "Openning");
		busy = 1;
	} else {
		printk(KERN_ALERT ">>> ERROR Opening, periph busy");
		return -EINVAL;
	}
	return 0;
}

int Myrelease (struct inode * iode, struct file * fille){
	busy = 0;
	newOpen = 1;
	printk(KERN_ALERT "periph free \n");
	return 0;
}

int buffer_init(void) {
	if (alloc_chrdev_region(&dev, 0, 1, "buffer") < 0 ){
		printk(KERN_ALERT">>> ERROR alloc_chrdev_region\n");
		return -EINVAL;
	}
	printk(KERN_ALERT "Hello buffer \n");
	my_cdev = cdev_alloc();
	my_cdev->ops = &fops;
	my_cdev->owner = THIS_MODULE;
	cdev_add(my_cdev,dev,1);
	return 0;
}


void buffer_cleanup(void) {
	unregister_chrdev_region(dev,1);
	cdev_del(my_cdev);
	printk(KERN_ALERT "Goodbye Cruel buffer \n");
	struct s_liste *unElement;
		struct list_head *ptr;
		struct list_head *next;
		list_for_each_safe(ptr, next, &MaListe){
			unElement = list_entry(ptr, struct s_liste, liste);
			list_del(ptr);
			kfree(unElement);
		}
}



module_init(buffer_init);
module_exit(buffer_cleanup);


MODULE_LICENSE(LICENCE);
MODULE_AUTHOR(AUTEUR);
MODULE_DESCRIPTION(DESCRIPTION);
MODULE_SUPPORTED_DEVICE(DEVICE);
