#!/bin/sh 
module="MyModule" 
device="PC" 
# appelle rmmod avec les arguments 
/sbin/rmmod $module $* || exit 1 
# supprime l’occurrence du noeud 
rm -f /dev/${device} 
